package com.nace.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nace.data.NaceDetails;

@Repository
public interface NaceRepository extends JpaRepository<NaceDetails, Integer>{
}
