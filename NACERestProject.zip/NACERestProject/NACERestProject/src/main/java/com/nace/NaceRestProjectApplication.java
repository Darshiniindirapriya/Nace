package com.nace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaceRestProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(NaceRestProjectApplication.class, args);
	}

}
