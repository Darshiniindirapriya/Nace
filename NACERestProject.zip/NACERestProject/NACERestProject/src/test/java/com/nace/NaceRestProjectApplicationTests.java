package com.nace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaceRestProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
